# HeartLink V10 — Bangladesh Mobile Banking Payment

এই ভার্সনে ব্যাংক/ডেবিট কার্ড UI বাদ দিয়ে Premium-এর জন্য **bKash, Nagad, Rocket**-ভিত্তিক mobile-banking checkout রাখা হয়েছে। SSLCOMMERZ Hosted Checkout ব্যবহার করা হয়েছে; gateway-এর active mobile-banking channels merchant account/configuration অনুযায়ী দেখাবে।

## Payment flow
HeartLink Premium → Pay → SSLCOMMERZ Hosted Checkout → mobile banking channel → IPN/server validation → verified হলে Premium Active।

SSLCOMMERZ-এর official docs অনুযায়ী Create/Get Session, IPN এবং Order Validation API ব্যবহার করা উচিত; শুধু browser redirect দেখে payment সফল ধরা যাবে না।

## Important
- এই ZIP-এ **real merchant credential দেওয়া নেই**।
- `.env.example` কপি করে `.env` বানিয়ে `SSLCOMMERZ_STORE_ID` এবং `SSLCOMMERZ_STORE_PASSWORD` বসাতে হবে।
- Sandbox testing-এর জন্য `SSLCOMMERZ_SANDBOX=true` রাখো।
- `PUBLIC_BASE_URL` অবশ্যই gateway callback/IPN গ্রহণ করতে পারে এমন publicly reachable URL হতে হবে; production-এ HTTPS ব্যবহার করো।
- Live payment চালু করার আগে SSLCOMMERZ merchant onboarding/approval শেষ করতে হবে।
- HeartLink নিজে bKash PIN/OTP/card data নেয় না; hosted gateway-এ payment হবে।
- Plan prices editable: monthly ৳999, quarterly ৳2,499, yearly ৳7,999।
- Production-এ JWT_SECRET শক্ত random secret দিতে হবে।

## Run
cd backend
npm install
cp .env.example .env
# .env edit
npm start

Frontend: frontend/index.html

## Backend endpoints
POST /api/payment/sslcommerz/session
POST /api/payment/sslcommerz/success
POST /api/payment/sslcommerz/fail
POST /api/payment/sslcommerz/cancel
POST /api/payment/sslcommerz/ipn
GET  /api/payment/orders

## Official docs
SSLCOMMERZ documentation:
https://sslcommerz.com/integration-document/
Sandbox docs:
https://sandbox-gw.sslcommerz.com/docs

## Security
Payment order amount/plan/currency is checked against the server database before Premium activation. IPN is processed server-side and the transaction is validated with the provider.
