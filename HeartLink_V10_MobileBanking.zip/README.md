# HeartLink V8 — Payment + Premium Feature Lock

এই V8-এ:
- Monthly / 3-month / Yearly Premium plans
- Server-side Premium verification
- Free vs Premium daily limits
- Payment order ও webhook-event tables
- Idempotency foundation
- Demo checkout (real money নয়)
- Photo upload foundation
- 18+ registration foundation

## Free limits
20 Likes/day • 1 Super Like/day • 50 Messages/day

## Premium limits
200 Likes/day • 10 Super Likes/day • 500 Messages/day

## Run
1. Node.js + PostgreSQL install করুন।
2. Database তৈরি করুন।
3. `psql "$DATABASE_URL" -f backend/schema.sql`
4. `backend/.env.example` কপি করে `.env` বানান।
5. `cd backend && npm install && npm start`
6. `frontend/index.html` browser-এ খুলুন।

Demo payment শুধু local testing-এর জন্য। `.env`-এ `ENABLE_DEMO_PAYMENT=true` করলে demo activation কাজ করবে।

### Real payment-এর আগে
কোনো real provider (যেমন Stripe, SSLCOMMERZ, bKash ইত্যাদি) যুক্ত করার সময় server-side hosted checkout, webhook signature verification, idempotency, renewal/cancel events এবং HTTPS অবশ্যই যোগ করতে হবে। Browser-এর success message দেখে Premium activate করা যাবে না।

Production-এ আরও দরকার: rate limiting, secure secrets, input validation, real 18+ verification, privacy/terms, object storage for photos এবং WebRTC-এর জন্য TURN server।


## V9 additions
- Notification inbox API: `/api/notifications`
- Mark notifications read: `/api/notifications/read`
- Online/offline presence API
- Push-token storage foundation
- Match notifications
- Message notifications
- Server-side message limit enforcement
- REST chat endpoints with authorization checks
- Provider-ready payment architecture retained from V8

### Real payment note
No real payment provider is activated in V9. To accept real money, choose a provider and implement its official hosted checkout and signed webhook verification on the server. Never mark an order paid from the browser.


## V10 payment note
V10 uses SSLCOMMERZ hosted checkout for Bangladesh mobile banking (bKash/Nagad/Rocket). See README_V10_PAYMENT.md.
